<?php ?>
<script>
function edditcat(val, target, idnty ) {
/* alert("GLOBAL Function CALLED"); */
$('#globalform').attr('action',target);
$('#globalform input[type="hidden"]').val(val);
$('#globalform input[type="hidden"]').attr('name', idnty);
$('#globalform').submit();
return true;
}
</script>

<form id="globalform" method="post" action="" encrypt="multi/form data">
<input type="hidden" name="data" value="" id="data_id">
</form>


<script>
	function edditcat1(val1, idnty1 ) 
	{
		/* alert("GLOBAL Function CALLED"); */
		$('#globalform1 input[type="hidden"]').val(val1);
		$('#globalform1 input[type="hidden"]').attr('name', idnty1);
		$('#globalform1').submit();return true;}
</script>
	<form id="globalform1" method="post" action="" encrypt=multi/form data>
		<input type="hidden" name="data1" value="" id="data_id1">
	</form>