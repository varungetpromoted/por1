<?php session_start(); ob_start(); include("config.inc.php");
#####--------------------  BEGIN GET All website link ----------------------------#####
function _pageuri(){ return $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";  }
function _siteuri(){ return $site_urlss = 'http://localhost/por1/'; }
function _hosturi(){ return $site_urlss = 'http://localhost/por1'; }

#####=====================BEGIN ALL WEBSITE LINK=======================#####
function _login(){ return _siteuri()."login.php"; }
function _logout(){ return _siteuri()."logout.php"; }
function _signup(){ return _siteuri()."signup.php"; }
function _home(){ return _siteuri(); }
function _findfrienduri(){ return _siteuri()."find-friends.php"; }
function _msguri(){ return _siteuri()."message.php"; }

#####=====================WEBSYTE NAME, COPYRIGHT and EMAIL ID'S FOR CONNETION=======================#####
function _sitename(){ return 'Sporfield'; }
function _admin(){ return 'Paulo Volpi'; }
function _copyright(){ return 'Copyright &copy; 2016 sporfield.com. All rights reserved.'; }
function _emailfrom(){ return 'admin@sporfield.com'; }
function _emailcontactus(){ return 'info@sporfield.com'; }

#####=============FACEBOOK SHARE FOR ENGLISH VERSION===================#####
function _fbtitleen(){ return 'Sporfield - Social Sports Network'; }
function _fbtypeen(){ return 'Sport'; }
function _fbdescen(){ return 'Connect with players, scouts, trainers, general managers and clubs. Increase your network and reach your true potential. Update your profile and keep your friends updated on your sport career.'; }
#####=============FACEBOOK SHARE FOR ITALIAN VERSION===================#####
function _fbtitleit(){ return 'Sporfield - Il social network dello sport'; }
function _fbtypeit(){ return 'Sport'; }
function _fbdescit(){ return 'Connettiti con giocatori, scouts, allenatori, direttori sportivi e clubs. Aumenta il tuo network e raggiungi il tuo massimo potenziale. Aggiorna costantemente il tuo profilo e tieni informati i tuoi amici sulla tua carriera sportiva.'; }
#####=====================BEGIN INCLUDE ALL WEBSITE FILE=======================#####

//function _fbfunction(){ return include("include/functions.php"); }
function _signupheader(){ return include("include/signup_header.php"); }//signup header
function _signupfooter(){ return include("include/signup_footer.php"); }//signup footer
function _loginheader(){ return include("include/login_header.php"); }//login header 
function _loginfooter(){ return include("include/login_footer.php"); }//login footer
function _homeheader(){ return include("include/home_header.php"); }
function _homefooter(){ return include("include/home_footer.php"); }
function _pagesheader(){ return include("include/pages_header.php"); }
function _pagesfooter(){ return include("include/pages_footer.php"); }
function _header(){ return include("include/header.php"); }
function _footer(){ return include("include/footer.php"); }
function _searchuserheader(){ return include("include/search-user-header.php"); }
function _searchuserfooter(){ return include("include/search-user-footer.php"); }
function _menu(){ return include("include/menu.php"); }
//function _globalfile(){ return include(_siteuri()."config/globalfunction.php"); }
function _validation(){ return include("validation.php"); }
function _ajaxsubmit(){ return include("ajax_submit.php"); }
function _countrydropdown(){ return include("include/countrydropdown.php"); }
function _imgupload(){ return include("ajax_img_upload.php"); }

#####======================BEGIN ADD COMMAN IMAGES================================#####

function _logo(){ return _siteuri().'images/logo.png'; }
function _logoadmin(){ return _siteuri().'images/logo.jpg'; }
function _favicon(){ return _siteuri().'favicon/favicon-32x32.png';  }

function _fbloader(){ return _siteuri().'images/fbloader.gif'; }
function _loadingimg(){ return _siteuri().'images/ajax-loader.gif'; }
function _loadingimg1(){ return _siteuri().'images/ajax-loader-horizentel.gif'; }
function _largeloader(){ return _siteuri().'images/large_loader.gif'; }
function _notavleimg(){ return _siteuri().'images/not-available.png'; }
function _availableimg(){ return _siteuri().'images/available.png'; }
function _camicon(){ return _siteuri().'images/cam.png'; }

function _userdummyimage(){ return _siteuri().'images/dummyUser.jpg'; }
function _userdummyimage20(){ return _siteuri().'images/dummyUser20.jpg'; }
function _userdummyimage50(){ return _siteuri().'images/dummyUser50.jpg'; }
function _userdummyimage100(){ return _siteuri().'images/dummyUser100.jpg'; }
function _userdummyimage200(){ return _siteuri().'images/dummyUser200.jpg'; }

function _resultnotfound(){ return _siteuri().'images/no_results_found.jpg'; }
function _defaultgroup(){ return _siteuri().'images/defaultgroup.png'; }
function _groupimg(){ return _siteuri().'images/groups.png'; }
function _eventimg(){ return _siteuri().'images/groups.png'; }


##=========================== MYSQL QUERY ============================================##
######  SELECT QUERY FOR ALL ####
function _sql($tbl,$args,$order){
if($args=='NULL')
	{ 
		$sql_query.="select * from ".$tbl.""; 
	}
	if($args!='NULL')
	{
		$counterno=1;
		$arraysize=count($args);
		$sql_query.="select * from ".$tbl." where ";

			foreach($args as $key => $value)
			{
				$sql_query.= " ".$key."='".$value."' ";
				if($counterno<$arraysize){ $sql_query.=" AND ";  }
				$counterno++;
			}

	}
	if($order!='NULL')
	{
		foreach($order as $keys => $values)
			{
				$sql_query.= "  ORDER BY ".$keys."  ".$values." ";
			}
	
	}

#return $sql_query;
$queryforexcute=mysql_query($sql_query);
return $queryforexcute; 

}

##=============  INSERT QUERY FOR ALL ===============##
function _insert($tbl,$args){
if($args!='NULL'){
$insert_counter=1;
$arraysize=count($args);
$insert_query.="insert into ".$tbl." set ";

foreach($args as $key => $value){
$insert_query.= " ".$key."='".$value."'";
if($insert_counter<$arraysize){ $insert_query.=",";  }
$insert_counter++;
}

}
$query_excute=mysql_query($insert_query);
return $query_excute; 
}

##============= UPDATE QUERY FOR ALL =================##
function _update($tbl,$args,$where){
if($args!='NULL'){
$update_counter=1;
$arraysize=count($args);
$update_query.="update ".$tbl." set ";

foreach($args as $key => $value){
$update_query.= " ".$key."='".$value."'";
if($update_counter<$arraysize){ $update_query.=",";  }
$update_counter++;
}

foreach($where as $keys => $values){
$update_query.= "  where ".$keys."='".$values."'";
}

}
$query_excute=mysql_query($update_query);
return $query_excute;
}

##============= MYSQL FETCH OBJECT ================##

function _obj($data){
$row_object_result=mysql_fetch_object($data);
return $row_object_result;
}

##============= MYSQL NUM ROWS ===============##
function _num($datas){
$num_count=mysql_num_rows($datas);
return $num_count;
}

##============= GENERATE RANDOM NUMBER  ============##
function _rend(){
$min = 5000;
$max = 500000;
$total = 7;
$rand = array();
while (count($rand) < $total ) {
    $r = mt_rand($min,$max);
    if (!in_array($r,$rand)) $rand[] = $r;
}
function randString($length, $charset='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz')
{
    $str = '';
    $count = strlen($charset);
    while ($length--) {
        $str .= $charset[mt_rand(0, $count-1)];
    }
    return $str;
	
}

 $rand1=randString(2);

return $random_number=md5($rand1.$r);

}

##=============  IMAGE UPLOAD  ===============##
function _uploadimg($imgname,$temp,$imgpath){
$rndno=rand(0000000000,9999999999);
if((isset($imgname)) && $imgname!='')
	{
	$path=$imgpath;
	$photo=$rndno.$imgname;
	$database_name=_siteuri().$path.$photo;
	move_uploaded_file($temp,$path.$photo);
	}
	return $database_name;				
}						

##=============Alert For Wrong Message===================###
function _message($msg){
return '<span style="font-size:18px;font-style:italic;color:red;">'.$msg.'</span>';   
}

##=============Alert For successful Message===================###
function _successmsg($msg){
return '<span style="font-size:18px;font-style:italic;color:green;">'.$msg.'</span>';   
}


##=============Mail Function===================###
function _emailsend($to,$fromemail,$subject,$message){
	$headers='MIME-Version: 1.0'."\r\n";
	$headers.='Content-type: text/html; charset=iso-8859-1'."\r\n";
	$headers.='From:'.$fromemail."\r\n";
	$emailsend=mail($to,$subject,$message,$headers);
	if($emailsend)
	{
		mail('mohit.getpromoted@gmail.com',$subject,$message,$headers);
		return 1;	
	}
}

function yearDropdown($startYear, $endYear, $ids){ 
    //start the select tag 
    echo "<select id=".$ids." name=".$ids." class='form-control'>n";
        //echo each year as an option     
        for ($i=$startYear;$i<=$endYear;$i++){ 
        echo "<option value=".$i.">".$i."</option>n";     
        } 
      
    //close the select tag 
    echo "</select>"; 
} 
##============= GET CURRENT TIME STAMP ===================###
if (isset($_SESSION['offset'])) { 
$minutes = $_SESSION['offset'];  
$local = gmmktime(gmdate("H"),gmdate("i")-$minutes); // adjust GMT by client's offset 
$current_datetime=gmdate("Y-m-d h:i:s",$local); 
$current_datetime_am=gmdate("Y-m-d h:i:s a",$local); 
$current_date=gmdate("Y-m-d",$local); 
}
$current_date_n=date('d F, Y');


##============= OUR FRIENDS LIST ===================###
	$sql_friends_execute=mysql_query("SELECT * FROM `friends` WHERE status=1 AND delete_status=0 AND accept_status=1");
	while($obj_frndz=_obj($sql_friends_execute)):
	$arrdta=explode(",",$obj_frndz->users_ids);
	if(in_array($_SESSION['register_id'], $arrdta))
	{
		$frinds_ids[]=$obj_frndz->users_ids;
	}
	endwhile;
	if(count($frinds_ids)>0)
	{
		$convert_string=implode(',',$frinds_ids);
		$remove_dupligate=array_unique(explode(",",$convert_string));
		$index = array_search($_SESSION['register_id'], $remove_dupligate);
			if ( $index !== false ) {
				unset( $remove_dupligate[$index] );
			}
		$friends_counter=count($remove_dupligate);
		$original_ids=implode(',',$remove_dupligate);
	}
	if($original_ids){ $original_ids_new=$original_ids; }else{ $original_ids_new=0; }
	
	
##============= OUR FRIENDS INCLUDE OURSELF LIST ===================###
	$sql_friends_execute1=mysql_query("SELECT * FROM `friends` WHERE status=1 AND delete_status=0 AND accept_status=1");
	while($obj_frndz1=_obj($sql_friends_execute1)):
	$arrdta1=explode(",",$obj_frndz1->users_ids);
	if(in_array($_SESSION['register_id'], $arrdta1))
	{
		$frinds_ids1[]=$obj_frndz1->users_ids;
	}
	endwhile;
	if(count($frinds_ids1)>0)
	{
		$convert_string1=implode(',',$frinds_ids1);
		$remove_dupligate1=array_unique(explode(",",$convert_string1));
		$original_ids1=implode(',',$remove_dupligate1);
	}
	if(!empty($original_ids1)){ $frndids_withme=$original_ids1; }else{ $frndids_withme=$_SESSION['register_id'].',0'; }
		
##============= MY CREATE GROUP AND MEMBER GROUP COUNT ===================###
$mycreate_group_count=_num(mysql_query("SELECT * FROM `groups_meta` WHERE status=1 AND delete_status=0 AND group_creater_id='".$_SESSION['register_id']."' AND group_sport_id='".$_SESSION['sport_ids']."'"));

$sql_member_grp=mysql_query("SELECT * FROM `groups_meta` WHERE status=1 AND delete_status=0 AND group_creater_id!='".$_SESSION['register_id']."' AND group_sport_id='".$_SESSION['sport_ids']."'");
$grmmbr_count=0;
while($obj_membr_grps=_obj($sql_member_grp)):
$global_mbrarr=explode(",",$obj_membr_grps->group_members_id);
if(in_array($_SESSION['register_id'], $global_mbrarr)) { $menbr_arr[]=$grmmbr_count+1; }
endwhile;
$membr_group_count=count($menbr_arr);

$total_group_count = $mycreate_group_count + $membr_group_count;

	function get_numerics ($str) {
		preg_match_all('/\d+/', $str, $matches);
		return $matches[0];
	}
?>
