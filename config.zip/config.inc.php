<?php /* //set parameters */
$dbuser = 'paolovol_dbuser1';
$dbpassword = 'paolovol@12345';
$dbname = 'paolovol_spdbv2';
if(mysql_connect('localhost',$dbuser,$dbpassword)) { }else{ die('Could not connect: ' . mysql_error()); }
unset($dbpassword);
unset($dbuser);
$db_selected=mysql_select_db($dbname);if (!$db_selected) {  die ('issues with DB : ' . mysql_error());}
unset($dbname);
error_reporting(E_ALL ^ E_NOTICE);
/* mysql_close($conn_mysql); */
?>